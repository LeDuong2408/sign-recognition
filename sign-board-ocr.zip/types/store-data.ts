export interface StoreData {
  name: string
  address: string
  phone: string
}
