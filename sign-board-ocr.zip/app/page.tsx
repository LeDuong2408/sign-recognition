import { SignBoardOCR } from "@/components/sign-board-ocr"

export default function Home() {
  return (
    <main className="container mx-auto py-10 px-4 md:px-6">
      <div className="flex flex-col items-center space-y-6">
        <h1 className="text-3xl font-bold text-center">Trích Xuất Dữ Liệu Từ Bảng Hiệu</h1>
        <p className="text-muted-foreground text-center max-w-2xl">
          Tải lên hình ảnh bảng hiệu quảng cáo để trích xuất thông tin cửa hàng như tên, địa chỉ và số điện thoại.
        </p>
        <SignBoardOCR />
      </div>
    </main>
  )
}
