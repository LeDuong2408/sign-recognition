"use server"

import { put, list } from "@vercel/blob"
import type { StoreData } from "@/types/store-data"

export interface HistoryItem {
  id: string
  url: string
  name: string
  timestamp: number
}

// Hàm tải lên hình ảnh và trích xuất dữ liệu
export async function uploadAndExtract(formData: FormData): Promise<{ results: StoreData[] }> {
  const files: File[] = []
  const entries = Array.from(formData.entries())

  for (const [key, value] of entries) {
    if (key.startsWith("image-") && value instanceof File) {
      files.push(value)
    }
  }

  if (files.length === 0) {
    throw new Error("Không có file nào được chọn")
  }

  try {
    // 1. Tải lên hình ảnh lên Vercel Blob
    const uploadPromises = files.map(async (file) => {
      // Tạo tên file duy nhất để tránh trùng lặp
      const uniqueFileName = `sign-board-ocr/${Date.now()}-${Math.random().toString(36).substring(2, 15)}-${file.name}`

      // Tải lên Vercel Blob
      const blob = await put(uniqueFileName, file, {
        access: "public",
        addRandomSuffix: false, // Đã thêm suffix ngẫu nhiên ở trên
      })

      return blob.url
    })

    const imageUrls = await Promise.all(uploadPromises)

    // 2. Trích xuất dữ liệu từ các URL hình ảnh
    const results = await extractSignBoardData(imageUrls)

    return {
      results,
    }
  } catch (error) {
    console.error("Lỗi khi xử lý hình ảnh:", error)
    throw new Error("Không thể xử lý hình ảnh. Vui lòng thử lại sau.")
  }
}

// Hàm lấy lịch sử tải lên từ Vercel Blob
export async function getUploadHistory(): Promise<HistoryItem[]> {
  try {
    // Lấy danh sách các file từ Vercel Blob
    const { blobs } = await list({ prefix: "sign-board-ocr/" })

    // Chuyển đổi thành định dạng HistoryItem
    const historyItems: HistoryItem[] = blobs.map((blob) => {
      const fileName = blob.pathname.split("/").pop() || "unknown"
      // Trích xuất tên file gốc từ tên file đã tải lên
      const originalName = fileName.split("-").slice(2).join("-") || fileName

      return {
        id: blob.pathname,
        url: blob.url,
        name: originalName,
        timestamp: blob.uploadedAt?.getTime() || Date.now(),
      }
    })

    // Sắp xếp theo thời gian tải lên, mới nhất lên đầu
    return historyItems.sort((a, b) => b.timestamp - a.timestamp)
  } catch (error) {
    console.error("Lỗi khi lấy lịch sử tải lên:", error)

    // Trả về một số hình ảnh mẫu nếu có lỗi
    return [
      {
        id: "sample-1",
        url: "/placeholder.svg?height=400&width=600",
        name: "Cửa hàng mẫu 1",
        timestamp: Date.now() - 86400000,
      },
      {
        id: "sample-2",
        url: "/placeholder.svg?height=400&width=600",
        name: "Cửa hàng mẫu 2",
        timestamp: Date.now() - 172800000,
      },
      {
        id: "sample-3",
        url: "/placeholder.svg?height=400&width=600",
        name: "Cửa hàng mẫu 3",
        timestamp: Date.now() - 259200000,
      },
    ]
  }
}

export async function extractSignBoardData(imageUrls: string[]): Promise<StoreData[]> {
  try {
    // Gọi API OCR thực tế
    const OCR_API_URL = process.env.OCR_API_URL || "https://api.ocr-service.com/extract"
    const OCR_API_KEY = process.env.OCR_API_KEY

    if (!OCR_API_KEY) {
      throw new Error("OCR API key không được cấu hình")
    }

    // Gọi API OCR với các URL hình ảnh
    const response = await fetch(OCR_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${OCR_API_KEY}`,
      },
      body: JSON.stringify({
        images: imageUrls,
        options: {
          language: "vi",
          detectStoreInfo: true,
        },
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error("Lỗi từ API OCR:", errorText)
      throw new Error(`Lỗi khi gọi API OCR: ${response.status}`)
    }

    const data = await response.json()

    // Chuyển đổi kết quả từ API sang định dạng StoreData
    // Điều chỉnh theo cấu trúc phản hồi thực tế từ API của bạn
    const results: StoreData[] = data.results.map((result: any) => ({
      name: result.store_name || "",
      address: result.address || "",
      phone: result.phone_number || "",
    }))

    return results
  } catch (error) {
    console.error("Lỗi khi trích xuất dữ liệu:", error)

    // Nếu có lỗi, trả về dữ liệu mẫu để kiểm tra giao diện
    // Trong môi trường sản xuất, bạn có thể muốn ném lỗi thay vì trả về dữ liệu mẫu
    return imageUrls.map((_, i) => ({
      name: `Cửa hàng mẫu ${i + 1}`,
      address: `Địa chỉ mẫu ${i + 1}`,
      phone: `0${Math.floor(Math.random() * 900000000) + 100000000}`,
    }))
  }
}
