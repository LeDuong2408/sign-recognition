"use client"

import type React from "react"
import type { StoreData } from "@/types/store-data"

import { useState, useEffect } from "react"
import { X, ZoomIn, ZoomOut, RotateCw, Building2, MapPin, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface ImagePreviewProps {
  isOpen: boolean
  imageUrl: string
  onClose: () => void
  imageTitle?: string
  storeData?: StoreData
}

export function ImagePreview({ isOpen, imageUrl, onClose, imageTitle, storeData }: ImagePreviewProps) {
  const [scale, setScale] = useState(1)
  const [rotation, setRotation] = useState(0)
  const [showInfo, setShowInfo] = useState(!!storeData)

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose()
      }
    }

    window.addEventListener("keydown", handleEscape)
    return () => window.removeEventListener("keydown", handleEscape)
  }, [isOpen, onClose])

  useEffect(() => {
    // Reset scale and rotation when opening a new image
    if (isOpen) {
      setScale(1)
      setRotation(0)
      setShowInfo(!!storeData)
    }
  }, [isOpen, imageUrl, storeData])

  if (!isOpen) return null

  const handleZoomIn = () => {
    setScale((prev) => Math.min(prev + 0.25, 3))
  }

  const handleZoomOut = () => {
    setScale((prev) => Math.max(prev - 0.25, 0.5))
  }

  const handleRotate = () => {
    setRotation((prev) => (prev + 90) % 360)
  }

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose()
    }
  }

  const toggleInfo = () => {
    setShowInfo((prev) => !prev)
  }

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center" onClick={handleBackdropClick}>
      <div className="relative max-w-[95vw] max-h-[95vh] flex flex-col md:flex-row gap-4 items-center">
        {/* Các nút điều khiển được đặt ở phía trên hình ảnh */}
        <div className="absolute top-2 left-2 flex gap-2 z-10">
          <Button size="icon" variant="secondary" onClick={handleZoomIn} className="bg-white/80 hover:bg-white">
            <ZoomIn className="h-4 w-4" />
            <span className="sr-only">Phóng to</span>
          </Button>
          <Button size="icon" variant="secondary" onClick={handleZoomOut} className="bg-white/80 hover:bg-white">
            <ZoomOut className="h-4 w-4" />
            <span className="sr-only">Thu nhỏ</span>
          </Button>
          <Button size="icon" variant="secondary" onClick={handleRotate} className="bg-white/80 hover:bg-white">
            <RotateCw className="h-4 w-4" />
            <span className="sr-only">Xoay</span>
          </Button>
          {storeData && (
            <Button
              size="icon"
              variant="secondary"
              onClick={toggleInfo}
              className={`bg-white/80 hover:bg-white ${showInfo ? "text-primary" : ""}`}
            >
              <Building2 className="h-4 w-4" />
              <span className="sr-only">Thông tin</span>
            </Button>
          )}
        </div>

        {/* Nút đóng được đặt ở góc trên bên phải */}
        <div className="absolute top-2 right-2 z-10">
          <Button
            size="icon"
            variant="destructive"
            onClick={onClose}
            className="bg-white/80 hover:bg-white text-red-500"
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Đóng</span>
          </Button>
        </div>

        <div className="bg-white/10 backdrop-blur-sm p-1 rounded-lg overflow-hidden max-w-full max-h-[85vh]">
          <img
            src={imageUrl || "/placeholder.svg"}
            alt={imageTitle || "Hình ảnh xem trước"}
            className="max-w-full max-h-[85vh] object-contain transition-transform duration-200"
            style={{
              transform: `scale(${scale}) rotate(${rotation}deg)`,
            }}
          />
          {imageTitle && !storeData && (
            <div className="bg-black/50 text-white text-sm py-2 px-4 text-center absolute bottom-0 left-0 right-0">
              {imageTitle}
            </div>
          )}
        </div>

        {storeData && showInfo && (
          <Card className="bg-white/90 backdrop-blur-sm shadow-lg max-w-md w-full md:w-80 self-start mt-12 md:mt-0">
            <CardContent className="p-4 space-y-4">
              <div>
                <h3 className="text-lg font-semibold mb-2">Thông tin trích xuất</h3>
                <p className="text-xs text-muted-foreground mb-4">Từ hình ảnh: {imageTitle}</p>
              </div>

              <div className="space-y-3">
                <div>
                  <div className="flex items-center mb-1">
                    <Building2 className="h-4 w-4 mr-1 text-primary" />
                    <p className="text-sm font-medium">Tên cửa hàng:</p>
                  </div>
                  <p className="text-base bg-white/50 p-2 rounded">{storeData.name || "Không xác định"}</p>
                </div>

                <div>
                  <div className="flex items-center mb-1">
                    <MapPin className="h-4 w-4 mr-1 text-muted-foreground" />
                    <p className="text-sm font-medium">Địa chỉ:</p>
                  </div>
                  <p className="text-base bg-white/50 p-2 rounded">{storeData.address || "Không xác định"}</p>
                </div>

                <div>
                  <div className="flex items-center mb-1">
                    <Phone className="h-4 w-4 mr-1 text-muted-foreground" />
                    <p className="text-sm font-medium">Số điện thoại:</p>
                  </div>
                  <p className="text-base bg-white/50 p-2 rounded">{storeData.phone || "Không xác định"}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
