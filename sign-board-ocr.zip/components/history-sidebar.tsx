"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Eye, Plus } from "lucide-react"
import type { HistoryItem } from "@/app/actions"

interface HistorySidebarProps {
  sampleImages: HistoryItem[]
  onSelect: (url: string, name: string) => void
  onPreview: (url: string, name: string) => void
  isLoading: boolean
}

export function HistorySidebar({ sampleImages, onSelect, onPreview, isLoading }: HistorySidebarProps) {
  // Hàm định dạng thời gian tương đối đơn giản
  const formatRelativeTime = (timestamp: number): string => {
    const now = Date.now()
    const diff = now - timestamp

    // Chuyển đổi mili giây thành phút, giờ, ngày
    const minutes = Math.floor(diff / (1000 * 60))
    const hours = Math.floor(diff / (1000 * 60 * 60))
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))

    if (minutes < 60) {
      return `${minutes} phút trước`
    } else if (hours < 24) {
      return `${hours} giờ trước`
    } else {
      return `${days} ngày trước`
    }
  }

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg">Hình ảnh mẫu</CardTitle>
        <p className="text-xs text-muted-foreground">Nhấp vào hình ảnh để thêm vào danh sách</p>
      </CardHeader>
      <CardContent className="space-y-4 max-h-[calc(100vh-200px)] overflow-y-auto">
        {sampleImages.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <p>Chưa có hình ảnh mẫu nào</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {sampleImages.map((item) => (
              <div key={item.id} className="cursor-pointer group relative">
                <div className="aspect-square rounded-md overflow-hidden border bg-muted">
                  <img
                    src={item.url || "/placeholder.svg"}
                    alt={item.name}
                    className="h-full w-full object-cover transition-transform group-hover:scale-105"
                  />
                </div>
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button
                    onClick={() => !isLoading && onSelect(item.url, item.name)}
                    className="text-white text-xs font-medium px-2 py-1 bg-black/50 rounded flex items-center gap-1 hover:bg-black/70"
                    disabled={isLoading}
                  >
                    <Plus className="h-3 w-3" />
                    Thêm
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      onPreview(item.url, item.name)
                    }}
                    className="text-white text-xs font-medium px-2 py-1 bg-black/50 rounded flex items-center gap-1 hover:bg-black/70"
                  >
                    <Eye className="h-3 w-3" />
                    Xem
                  </button>
                </div>
                <p className="text-xs truncate mt-1">{item.name}</p>
                <p className="text-xs text-muted-foreground">{formatRelativeTime(item.timestamp)}</p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
